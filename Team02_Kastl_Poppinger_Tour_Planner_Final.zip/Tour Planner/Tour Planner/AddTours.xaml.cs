﻿using System.Windows.Controls;

namespace Tour_Planner
{
    /// <summary>
    /// Interaction logic for AddTours.xaml
    /// </summary>
    public partial class AddTours : UserControl
    {
        public AddTours()
        {
            InitializeComponent();
        }
    }
}
